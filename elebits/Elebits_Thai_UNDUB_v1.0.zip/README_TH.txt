Elebits: The Adventures of Kai and Zero — แพตช์ภาษาไทย รุ่น 014
แปลโดยเพจแปลเกมเก่า

ใช้กับ ROM ต้นฉบับ 3153 - Elebits - Kai to Zero no Fushigi na Tabi (UNDUB).nds
รหัสเกม YERE รุ่น 0 ขนาด 60,695,676 ไบต์
SHA-256 ต้นฉบับ
0524cea911d47d77e2c903b10b80871383818a9cb82c8f72091cb6dac7182523

วิธีลงแพตช์
1. เปิดโปรแกรมที่รองรับ xdelta3 แล้วเลือก Elebits_Thai_UNDUB_v014.xdelta เป็นไฟล์แพตช์
2. เลือก ROM ต้นฉบับและตั้งชื่อไฟล์ผลลัพธ์ใหม่ เช่น Elebits_Thai_v014.nds
3. เปิดไฟล์ผลลัพธ์ด้วย DeSmuME

ตัวอย่างคำสั่ง xdelta3
xdelta3 -d -s "3153 - Elebits - Kai to Zero no Fushigi na Tabi (UNDUB).nds" "Elebits_Thai_UNDUB_v014.xdelta" "Elebits_Thai_v014.nds"

SHA-256 ROM หลังลงแพตช์
d68674e44311d5ae5f594cc4a80d8a109e25a129440833a9d0fc0f164b6184c9

SHA-256 ไฟล์แพตช์
5fcc2b586c125cabbf9461deffb22ccaf2ac6842338a3c9dca32b2e7b45c3093

รุ่นนี้ใช้ฟอนต์ CotM 8×12 และมีคำแปลไทยครบ 3,490 ระเบียนที่แปลได้
ตรวจเครดิตบนหน้าเลือกไฟล์ใน DeSmuME แล้ว
ทดสอบลงแพตช์จาก ROM ต้นฉบับและยืนยันว่าไฟล์ผลลัพธ์ตรงกับรุ่น 014
